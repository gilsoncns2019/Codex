// Sistema de testes básico para o Plugin Codex
// Este arquivo pode ser executado com Node.js para testar funcionalidades isoladas

const fs = require('fs');
const path = require('path');

class TestRunner {
  constructor() {
    this.tests = [];
    this.results = {
      passed: 0,
      failed: 0,
      total: 0
    };
  }

  addTest(name, testFunction) {
    this.tests.push({ name, testFunction });
  }

  async runTests() {
    console.log('🧪 Iniciando testes do Plugin Codex...\n');
    
    for (const test of this.tests) {
      try {
        console.log(`⏳ Executando: ${test.name}`);
        await test.testFunction();
        console.log(`✅ PASSOU: ${test.name}\n`);
        this.results.passed++;
      } catch (error) {
        console.log(`❌ FALHOU: ${test.name}`);
        console.log(`   Erro: ${error.message}\n`);
        this.results.failed++;
      }
      this.results.total++;
    }

    this.printSummary();
  }

  printSummary() {
    console.log('📊 RESUMO DOS TESTES');
    console.log('='.repeat(50));
    console.log(`Total de testes: ${this.results.total}`);
    console.log(`Passou: ${this.results.passed}`);
    console.log(`Falhou: ${this.results.failed}`);
    console.log(`Taxa de sucesso: ${((this.results.passed / this.results.total) * 100).toFixed(1)}%`);
    
    if (this.results.failed === 0) {
      console.log('\n🎉 Todos os testes passaram!');
    } else {
      console.log(`\n⚠️  ${this.results.failed} teste(s) falharam.`);
    }
  }
}

// Função auxiliar para verificar se um arquivo existe
function fileExists(filePath) {
  return fs.existsSync(filePath);
}

// Função auxiliar para ler conteúdo de arquivo
function readFile(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

// Função auxiliar para verificar se uma string contém determinado texto
function contains(text, substring) {
  return text.includes(substring);
}

// Função auxiliar para verificar se um objeto tem determinada propriedade
function hasProperty(obj, property) {
  return obj.hasOwnProperty(property);
}

// Criar instância do test runner
const testRunner = new TestRunner();

// TESTES DE ESTRUTURA DE ARQUIVOS
testRunner.addTest('Verificar existência do manifest.json', () => {
  const manifestPath = path.join(__dirname, '..', 'manifest.json');
  if (!fileExists(manifestPath)) {
    throw new Error('manifest.json não encontrado');
  }
  
  const manifest = JSON.parse(readFile(manifestPath));
  if (!hasProperty(manifest, 'id') || !hasProperty(manifest, 'name') || !hasProperty(manifest, 'version')) {
    throw new Error('manifest.json está incompleto');
  }
});

testRunner.addTest('Verificar existência do package.json', () => {
  const packagePath = path.join(__dirname, '..', 'package.json');
  if (!fileExists(packagePath)) {
    throw new Error('package.json não encontrado');
  }
  
  const packageJson = JSON.parse(readFile(packagePath));
  if (!hasProperty(packageJson, 'dependencies') || !hasProperty(packageJson, 'devDependencies')) {
    throw new Error('package.json está incompleto');
  }
});

testRunner.addTest('Verificar existência do main.js compilado', () => {
  const mainPath = path.join(__dirname, '..', 'main.js');
  if (!fileExists(mainPath)) {
    throw new Error('main.js compilado não encontrado. Execute npm run build primeiro.');
  }
});

testRunner.addTest('Verificar existência dos arquivos TypeScript principais', () => {
  const requiredFiles = [
    'src/main.ts',
    'src/settings.ts',
    'src/types.ts',
    'src/web-worker.ts',
    'src/agents/geminiClient.ts',
    'src/agents/ingestionAgent.ts',
    'src/agents/orchestrator.ts',
    'src/utils/markdownFormatter.ts',
    'src/utils/diagramGenerator.ts',
    'src/utils/latexFormatter.ts',
    'src/ui/progressModal.ts',
    'src/ui/fileSelector.ts'
  ];
  
  for (const file of requiredFiles) {
    const filePath = path.join(__dirname, '..', file);
    if (!fileExists(filePath)) {
      throw new Error(`Arquivo obrigatório não encontrado: ${file}`);
    }
  }
});

// TESTES DE CONFIGURAÇÃO
testRunner.addTest('Verificar configuração do TypeScript', () => {
  const tsconfigPath = path.join(__dirname, '..', 'tsconfig.json');
  if (!fileExists(tsconfigPath)) {
    throw new Error('tsconfig.json não encontrado');
  }
  
  const tsconfig = JSON.parse(readFile(tsconfigPath));
  if (!hasProperty(tsconfig, 'compilerOptions')) {
    throw new Error('tsconfig.json está mal configurado');
  }
});

testRunner.addTest('Verificar configuração do esbuild', () => {
  const esbuildPath = path.join(__dirname, '..', 'esbuild.config.mjs');
  if (!fileExists(esbuildPath)) {
    throw new Error('esbuild.config.mjs não encontrado');
  }
});

// TESTES DE DEPENDÊNCIAS
testRunner.addTest('Verificar dependências essenciais no package.json', () => {
  const packagePath = path.join(__dirname, '..', 'package.json');
  const packageJson = JSON.parse(readFile(packagePath));
  
  const requiredDeps = ['@google/generative-ai', 'pdfjs-dist'];
  const requiredDevDeps = ['obsidian', 'typescript', 'esbuild'];
  
  for (const dep of requiredDeps) {
    if (!hasProperty(packageJson.dependencies, dep)) {
      throw new Error(`Dependência obrigatória não encontrada: ${dep}`);
    }
  }
  
  for (const dep of requiredDevDeps) {
    if (!hasProperty(packageJson.devDependencies, dep)) {
      throw new Error(`Dependência de desenvolvimento obrigatória não encontrada: ${dep}`);
    }
  }
});

// TESTES DE CONTEÚDO
testRunner.addTest('Verificar estrutura do manifest', () => {
  const manifestPath = path.join(__dirname, '..', 'manifest.json');
  const manifest = JSON.parse(readFile(manifestPath));
  
  if (manifest.id !== 'obsidian-codex') {
    throw new Error('ID do plugin incorreto no manifest');
  }
  
  if (!manifest.name.includes('Codex')) {
    throw new Error('Nome do plugin incorreto no manifest');
  }
  
  if (!manifest.description || manifest.description.length < 10) {
    throw new Error('Descrição do plugin muito curta ou ausente');
  }
});

testRunner.addTest('Verificar imports principais no main.ts', () => {
  const mainPath = path.join(__dirname, '..', 'src', 'main.ts');
  const mainContent = readFile(mainPath);
  
  const requiredImports = [
    'Notice',
    'Plugin',
    'TFile',
    'CodexSettings',
    'ProgressModal',
    'FileSelectorModal'
  ];
  
  for (const importName of requiredImports) {
    if (!contains(mainContent, importName)) {
      throw new Error(`Import obrigatório não encontrado em main.ts: ${importName}`);
    }
  }
});

testRunner.addTest('Verificar definições de tipos', () => {
  const typesPath = path.join(__dirname, '..', 'src', 'types.ts');
  const typesContent = readFile(typesPath);
  
  const requiredTypes = [
    'CodexSettings',
    'ProcessingProgress',
    'PDFContent',
    'ConceptData',
    'QAData',
    'SummaryData',
    'ProcessedContent',
    'MarkdownNote'
  ];
  
  for (const typeName of requiredTypes) {
    if (!contains(typesContent, `interface ${typeName}`) && !contains(typesContent, `type ${typeName}`)) {
      throw new Error(`Tipo obrigatório não encontrado: ${typeName}`);
    }
  }
});

// TESTES DE DOCUMENTAÇÃO
testRunner.addTest('Verificar existência do README', () => {
  const readmePath = path.join(__dirname, '..', 'README.md');
  if (!fileExists(readmePath)) {
    throw new Error('README.md não encontrado');
  }
  
  const readmeContent = readFile(readmePath);
  if (readmeContent.length < 1000) {
    throw new Error('README.md muito curto - deve conter documentação detalhada');
  }
  
  const requiredSections = [
    '# Codex',
    '## Funcionalidades',
    '## Instalação',
    '## Configuração',
    '## Como Usar'
  ];
  
  for (const section of requiredSections) {
    if (!contains(readmeContent, section)) {
      throw new Error(`Seção obrigatória não encontrada no README: ${section}`);
    }
  }
});

testRunner.addTest('Verificar existência do arquivo de estilos', () => {
  const stylesPath = path.join(__dirname, '..', 'styles.css');
  if (!fileExists(stylesPath)) {
    throw new Error('styles.css não encontrado');
  }
  
  const stylesContent = readFile(stylesPath);
  if (!contains(stylesContent, '.codex-')) {
    throw new Error('styles.css não contém classes específicas do plugin');
  }
});

// TESTES DE SINTAXE E ESTRUTURA
testRunner.addTest('Verificar sintaxe JSON dos arquivos de configuração', () => {
  const jsonFiles = ['manifest.json', 'package.json', 'tsconfig.json'];
  
  for (const file of jsonFiles) {
    const filePath = path.join(__dirname, '..', file);
    try {
      JSON.parse(readFile(filePath));
    } catch (error) {
      throw new Error(`Sintaxe JSON inválida em ${file}: ${error.message}`);
    }
  }
});

testRunner.addTest('Verificar estrutura básica das classes principais', () => {
  const mainPath = path.join(__dirname, '..', 'src', 'main.ts');
  const mainContent = readFile(mainPath);
  
  if (!contains(mainContent, 'export default class') && !contains(mainContent, 'class CodexPlugin')) {
    throw new Error('Classe principal do plugin não encontrada em main.ts');
  }
  
  if (!contains(mainContent, 'onload()') || !contains(mainContent, 'onunload()')) {
    throw new Error('Métodos obrigatórios onload/onunload não encontrados');
  }
});

// Executar todos os testes
if (require.main === module) {
  testRunner.runTests().catch(console.error);
}

module.exports = { TestRunner, fileExists, readFile, contains, hasProperty };

