// Web Worker para processamento assíncrono de PDFs
import { AgentOrchestrator } from './agents/orchestrator';
import { WorkerMessage, WorkerResponse, ProcessingProgress } from './types';

// Contexto do Web Worker
const ctx: Worker = self as any;

let orchestrator: AgentOrchestrator | null = null;

// Listener para mensagens do thread principal
ctx.addEventListener('message', async (event: MessageEvent<WorkerMessage>) => {
  const { type, data } = event.data;

  try {
    switch (type) {
      case 'process-pdf':
        await handleProcessPDF(data);
        break;
      
      default:
        sendError(`Tipo de mensagem desconhecido: ${type}`);
    }
  } catch (error) {
    console.error('Erro no Web Worker:', error);
    sendError(error.message || 'Erro desconhecido no processamento');
  }
});

async function handleProcessPDF(data: any) {
  try {
    const { arrayBuffer, filename, settings } = data;

    // Validar dados recebidos
    if (!arrayBuffer || !filename || !settings) {
      throw new Error('Dados incompletos para processamento');
    }

    // Criar orquestrador com callback de progresso
    orchestrator = new AgentOrchestrator(settings, (progress: ProcessingProgress) => {
      sendProgress(progress);
    });

    // Validar configurações
    const validation = await orchestrator.validateSettings();
    if (!validation.valid) {
      throw new Error(`Configurações inválidas: ${validation.errors.join(', ')}`);
    }

    // Processar PDF
    const result = await orchestrator.processPDF(arrayBuffer, filename);

    // Enviar resultado
    sendResult(result);

  } catch (error) {
    console.error('Erro ao processar PDF:', error);
    sendError(error.message || 'Erro no processamento do PDF');
  }
}

function sendProgress(progress: ProcessingProgress) {
  const response: WorkerResponse = {
    type: 'progress',
    data: progress
  };
  ctx.postMessage(response);
}

function sendResult(result: any) {
  const response: WorkerResponse = {
    type: 'result',
    data: result
  };
  ctx.postMessage(response);
}

function sendError(message: string) {
  const response: WorkerResponse = {
    type: 'error',
    data: { message }
  };
  ctx.postMessage(response);
}

// Tratamento de erros não capturados
ctx.addEventListener('error', (error) => {
  console.error('Erro não capturado no Web Worker:', error);
  sendError(`Erro interno: ${error.message}`);
});

ctx.addEventListener('unhandledrejection', (event: PromiseRejectionEvent) => {
  console.error('Promise rejeitada não tratada no Web Worker:', event.reason);
  sendError(`Erro interno: ${event.reason}`);
});

// Log de inicialização
console.log('Web Worker do Codex inicializado');

export {}; // Para tornar este arquivo um módulo

