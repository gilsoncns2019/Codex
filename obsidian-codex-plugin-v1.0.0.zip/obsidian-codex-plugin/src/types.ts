// Tipos para o plugin Codex

export interface CodexSettings {
  geminiApiKey: string;
  geminiModel: string;
  enableOCR: boolean;
  ocrProvider: 'tesseract' | 'cloud';
  outputFolder: string;
  includeQA: boolean;
  includeConcepts: boolean;
  includeSummary: boolean;
  includeMermaidDiagrams: boolean;
  includeLatex: boolean;
  includeIcons: boolean;
}

export interface ProcessingProgress {
  stage: 'ingestion' | 'analysis' | 'generation' | 'complete' | 'error';
  message: string;
  percentage: number;
}

export interface PDFContent {
  text: string;
  metadata: {
    title?: string;
    author?: string;
    subject?: string;
    creator?: string;
    producer?: string;
    creationDate?: Date;
    modificationDate?: Date;
    pages: number;
  };
}

export interface ConceptData {
  name: string;
  category: 'person' | 'place' | 'theory' | 'formula' | 'term' | 'other';
  description: string;
  importance: 'high' | 'medium' | 'low';
}

export interface QAData {
  question: string;
  answer: string;
  difficulty: 'easy' | 'medium' | 'hard';
  category: string;
}

export interface SummaryData {
  abstract: string;
  keyPoints: string[];
  mainTopics: string[];
}

export interface ProcessedContent {
  summary: SummaryData;
  concepts: ConceptData[];
  qa: QAData[];
  originalText: string;
  metadata: PDFContent['metadata'];
}

export interface MarkdownNote {
  title: string;
  content: string;
  frontmatter: Record<string, any>;
  filename: string;
}

// Tipos para comunicação com Web Workers
export interface WorkerMessage {
  type: 'process-pdf' | 'progress-update' | 'processing-complete' | 'processing-error';
  data: any;
}

export interface WorkerResponse {
  type: 'progress' | 'result' | 'error';
  data: any;
}

