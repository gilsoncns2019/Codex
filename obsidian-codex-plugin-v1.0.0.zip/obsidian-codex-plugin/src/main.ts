import { Notice, Plugin, TFile } from 'obsidian';
import { CodexSettings, ProcessingProgress } from './types';
import { CodexSettingTab, DEFAULT_SETTINGS } from './settings';
import { ProgressModal } from './ui/progressModal';
import { FileSelectorModal } from './ui/fileSelector';

export default class CodexPlugin extends Plugin {
  settings: CodexSettings;
  private worker: Worker | null = null;
  private progressModal: ProgressModal | null = null;

  async onload() {
    await this.loadSettings();

    // Adicionar ícone na ribbon
    const ribbonIconEl = this.addRibbonIcon('file-text', 'Processar PDF com Codex', (evt: MouseEvent) => {
      this.showAdvancedFileSelector();
    });
    ribbonIconEl.addClass('codex-ribbon-class');

    // Adicionar comando na paleta de comandos
    this.addCommand({
      id: 'process-pdf',
      name: 'Processar PDF',
      callback: () => {
        this.showAdvancedFileSelector();
      }
    });

    // Adicionar comando para processar arquivo atual (se for PDF)
    this.addCommand({
      id: 'process-current-pdf',
      name: 'Processar PDF Atual',
      checkCallback: (checking: boolean) => {
        const activeFile = this.app.workspace.getActiveFile();
        if (activeFile && activeFile.extension === 'pdf') {
          if (!checking) {
            this.processPDF(activeFile);
          }
          return true;
        }
        return false;
      }
    });

    // Adicionar comando para testar conexão com Gemini
    this.addCommand({
      id: 'test-gemini-connection',
      name: 'Testar Conexão com Gemini',
      callback: async () => {
        await this.testGeminiConnection();
      }
    });

    // Adicionar aba de configurações
    this.addSettingTab(new CodexSettingTab(this.app, this));

    // Registrar manipulador de arquivos PDF (drag & drop)
    this.registerEvent(
      this.app.vault.on('create', (file) => {
        if (file instanceof TFile && file.extension === 'pdf') {
          this.showProcessingPrompt(file);
        }
      })
    );

    console.log('Plugin Codex carregado');
  }

  onunload() {
    if (this.worker) {
      this.worker.terminate();
      this.worker = null;
    }
    
    if (this.progressModal) {
      this.progressModal.close();
      this.progressModal = null;
    }
    
    console.log('Plugin Codex descarregado');
  }

  async loadSettings() {
    this.settings = Object.assign({}, DEFAULT_SETTINGS, await this.loadData());
  }

  async saveSettings() {
    await this.saveData(this.settings);
  }

  private showAdvancedFileSelector() {
    const fileSelector = new FileSelectorModal(this.app, (file) => {
      if (file instanceof TFile) {
        this.processPDF(file);
      } else {
        this.processPDFFromFile(file);
      }
    });
    fileSelector.open();
  }

  private showProcessingPrompt(file: TFile) {
    const notice = new Notice(`PDF detectado: ${file.name}. Clique no ícone do Codex para processar.`, 5000);
    
    // Adicionar botão de ação rápida na notice
    const noticeEl = (notice as any).noticeEl;
    if (noticeEl) {
      const quickButton = noticeEl.createEl('button', {
        text: 'Processar Agora',
        cls: 'mod-cta'
      });
      quickButton.style.marginLeft = '10px';
      quickButton.addEventListener('click', () => {
        notice.hide();
        this.processPDF(file);
      });
    }
  }

  private async testGeminiConnection() {
    if (!this.settings.geminiApiKey) {
      new Notice('Configure sua chave da API Gemini primeiro nas configurações.', 5000);
      return;
    }

    const testNotice = new Notice('Testando conexão com Gemini...', 0);
    
    try {
      // Importar dinamicamente para evitar problemas de bundling
      const { GeminiClient } = await import('./agents/geminiClient');
      const isValid = await GeminiClient.validateApiKey(this.settings.geminiApiKey);
      
      testNotice.hide();
      
      if (isValid) {
        new Notice('✅ Conexão com Gemini estabelecida com sucesso!', 5000);
      } else {
        new Notice('❌ Falha na conexão com Gemini. Verifique sua chave da API.', 5000);
      }
    } catch (error) {
      testNotice.hide();
      console.error('Erro ao testar conexão:', error);
      new Notice('❌ Erro ao testar conexão com Gemini.', 5000);
    }
  }

  private async processPDF(file: TFile) {
    if (!this.settings.geminiApiKey) {
      new Notice('Por favor, configure sua chave da API Gemini nas configurações do plugin.', 5000);
      return;
    }

    try {
      const arrayBuffer = await this.app.vault.readBinary(file);
      await this.processPDFFromArrayBuffer(arrayBuffer, file.name);
    } catch (error) {
      console.error('Erro ao ler arquivo PDF:', error);
      new Notice('Erro ao ler o arquivo PDF. Verifique se o arquivo não está corrompido.', 5000);
    }
  }

  private async processPDFFromFile(file: File) {
    if (!this.settings.geminiApiKey) {
      new Notice('Por favor, configure sua chave da API Gemini nas configurações do plugin.', 5000);
      return;
    }

    try {
      const arrayBuffer = await file.arrayBuffer();
      await this.processPDFFromArrayBuffer(arrayBuffer, file.name);
    } catch (error) {
      console.error('Erro ao processar arquivo:', error);
      new Notice('Erro ao processar o arquivo PDF.', 5000);
    }
  }

  private async processPDFFromArrayBuffer(arrayBuffer: ArrayBuffer, filename: string) {
    // Criar modal de progresso
    this.progressModal = new ProgressModal(this.app, () => {
      // Callback de cancelamento
      if (this.worker) {
        this.worker.terminate();
        this.worker = null;
      }
      new Notice('Processamento cancelado pelo usuário.', 3000);
    });
    
    this.progressModal.open();

    try {
      // Inicializar Web Worker
      if (!this.worker) {
        this.worker = new Worker(new URL('./web-worker.ts', import.meta.url));
        this.setupWorkerListeners();
      }

      // Enviar PDF para processamento
      this.worker.postMessage({
        type: 'process-pdf',
        data: {
          arrayBuffer,
          filename,
          settings: this.settings
        }
      });

    } catch (error) {
      console.error('Erro ao iniciar processamento:', error);
      if (this.progressModal) {
        this.progressModal.close();
        this.progressModal = null;
      }
      new Notice('Erro ao iniciar o processamento do PDF.', 5000);
    }
  }

  private setupWorkerListeners() {
    if (!this.worker) return;

    this.worker.onmessage = async (event) => {
      const { type, data } = event.data;

      switch (type) {
        case 'progress':
          this.handleProgressUpdate(data as ProcessingProgress);
          break;
        case 'result':
          await this.handleProcessingResult(data);
          break;
        case 'error':
          this.handleProcessingError(data);
          break;
      }
    };

    this.worker.onerror = (error) => {
      console.error('Erro no Web Worker:', error);
      if (this.progressModal) {
        this.progressModal.close();
        this.progressModal = null;
      }
      new Notice('Erro interno no processamento. Verifique o console para mais detalhes.', 5000);
    };
  }

  private handleProgressUpdate(progress: ProcessingProgress) {
    if (this.progressModal) {
      this.progressModal.updateProgress(progress);
    }
  }

  private async handleProcessingResult(result: any) {
    try {
      // Criar pasta de saída se não existir
      const outputFolder = this.settings.outputFolder;
      if (!await this.app.vault.adapter.exists(outputFolder)) {
        await this.app.vault.createFolder(outputFolder);
      }

      // Salvar nota gerada
      const notePath = `${outputFolder}/${result.filename}`;
      await this.app.vault.create(notePath, result.content);

      // Fechar modal de progresso
      if (this.progressModal) {
        this.progressModal.close();
        this.progressModal = null;
      }

      // Mostrar notice de sucesso com ação
      const successNotice = new Notice('', 8000);
      const noticeEl = (successNotice as any).noticeEl;
      noticeEl.innerHTML = `
        <div style="display: flex; align-items: center; gap: 10px;">
          <span>✅ Nota criada: ${result.filename}</span>
          <button class="mod-cta" style="padding: 4px 8px; font-size: 0.8em;">Abrir</button>
        </div>
      `;

      const openButton = noticeEl.querySelector('button');
      openButton?.addEventListener('click', async () => {
        successNotice.hide();
        const createdFile = this.app.vault.getAbstractFileByPath(notePath);
        if (createdFile instanceof TFile) {
          await this.app.workspace.getLeaf().openFile(createdFile);
        }
      });

    } catch (error) {
      console.error('Erro ao salvar nota:', error);
      if (this.progressModal) {
        this.progressModal.close();
        this.progressModal = null;
      }
      new Notice('Erro ao salvar a nota gerada.', 5000);
    }
  }

  private handleProcessingError(error: any) {
    console.error('Erro no processamento:', error);
    
    if (this.progressModal) {
      this.progressModal.updateProgress({
        stage: 'error',
        message: error.message || 'Erro desconhecido',
        percentage: 0
      });
    }
  }
}

