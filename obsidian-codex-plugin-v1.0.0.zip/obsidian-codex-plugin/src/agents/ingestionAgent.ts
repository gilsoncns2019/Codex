import * as pdfjsLib from 'pdfjs-dist';
import { PDFContent } from '../types';

// Configurar o worker do PDF.js
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/${pdfjsLib.version}/pdf.worker.min.js`;

export class IngestionAgent {
  
  async extractPDFContent(arrayBuffer: ArrayBuffer): Promise<PDFContent> {
    try {
      // Carregar o documento PDF
      const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;

      // Extrair metadados
      const metadata = await this.extractMetadata(pdf);

      // Extrair texto de todas as páginas
      let fullText = '';
      const totalPages = pdf.numPages;

      for (let pageNum = 1; pageNum <= totalPages; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        
        // Combinar todos os itens de texto da página
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        
        fullText += pageText + '\n\n';
      }

      // Limpar e normalizar o texto
      const cleanedText = this.cleanText(fullText);

      return {
        text: cleanedText,
        metadata: {
          ...metadata,
          pages: totalPages
        }
      };

    } catch (error) {
      console.error('Erro ao extrair conteúdo do PDF:', error);
      throw new Error(`Falha na extração do PDF: ${error.message}`);
    }
  }

  private async extractMetadata(pdf: any): Promise<PDFContent['metadata']> {
    try {
      const metadata = await pdf.getMetadata();
      const info = metadata.info as any;

      return {
        title: info?.Title || undefined,
        author: info?.Author || undefined,
        subject: info?.Subject || undefined,
        creator: info?.Creator || undefined,
        producer: info?.Producer || undefined,
        creationDate: info?.CreationDate ? new Date(info.CreationDate) : undefined,
        modificationDate: info?.ModDate ? new Date(info.ModDate) : undefined,
        pages: 0 // Será preenchido posteriormente
      };
    } catch (error) {
      console.warn('Erro ao extrair metadados:', error);
      return { pages: 0 };
    }
  }

  private cleanText(text: string): string {
    return text
      // Remover múltiplas quebras de linha
      .replace(/\n{3,}/g, '\n\n')
      // Remover espaços extras
      .replace(/[ \t]+/g, ' ')
      // Remover espaços no início e fim das linhas
      .replace(/^[ \t]+|[ \t]+$/gm, '')
      // Remover linhas vazias desnecessárias
      .replace(/^\s*\n/gm, '')
      // Normalizar quebras de linha
      .trim();
  }

  // Método para validar se o arquivo é um PDF válido
  static async validatePDF(arrayBuffer: ArrayBuffer): Promise<boolean> {
    try {
      const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;
      return pdf.numPages > 0;
    } catch (error) {
      return false;
    }
  }

  // Método para obter informações básicas do PDF sem extrair todo o conteúdo
  static async getPDFInfo(arrayBuffer: ArrayBuffer): Promise<{ pages: number; title?: string; author?: string }> {
    try {
      const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;
      const metadata = await pdf.getMetadata();
      const info = metadata.info as any;
      
      return {
        pages: pdf.numPages,
        title: info?.Title || undefined,
        author: info?.Author || undefined
      };
    } catch (error) {
      throw new Error(`Erro ao obter informações do PDF: ${error.message}`);
    }
  }

  // Método para extrair texto de páginas específicas (útil para PDFs grandes)
  async extractPageRange(arrayBuffer: ArrayBuffer, startPage: number, endPage: number): Promise<string> {
    try {
      const loadingTask = pdfjsLib.getDocument({ data: arrayBuffer });
      const pdf = await loadingTask.promise;

      let text = '';
      const actualEndPage = Math.min(endPage, pdf.numPages);
      const actualStartPage = Math.max(1, startPage);

      for (let pageNum = actualStartPage; pageNum <= actualEndPage; pageNum++) {
        const page = await pdf.getPage(pageNum);
        const textContent = await page.getTextContent();
        
        const pageText = textContent.items
          .map((item: any) => item.str)
          .join(' ');
        
        text += pageText + '\n\n';
      }

      return this.cleanText(text);
    } catch (error) {
      throw new Error(`Erro ao extrair páginas ${startPage}-${endPage}: ${error.message}`);
    }
  }
}

