import { GoogleGenerativeAI, GenerativeModel, GenerationConfig } from '@google/generative-ai';
import { ConceptData, QAData, SummaryData } from '../types';

export class GeminiClient {
  private genAI: GoogleGenerativeAI;
  private model: GenerativeModel;

  constructor(apiKey: string, modelName: string = 'gemini-2.5-flash') {
    this.genAI = new GoogleGenerativeAI(apiKey);
    this.model = this.genAI.getGenerativeModel({ model: modelName });
  }

  async generateSummary(text: string): Promise<SummaryData> {
    const prompt = `
Analise o seguinte texto e gere um resumo estruturado em formato JSON.

Texto para análise:
${text}

Retorne APENAS um objeto JSON válido com a seguinte estrutura:
{
  "abstract": "Resumo executivo conciso do documento (máximo 200 palavras)",
  "keyPoints": ["Ponto-chave 1", "Ponto-chave 2", "Ponto-chave 3"],
  "mainTopics": ["Tópico principal 1", "Tópico principal 2", "Tópico principal 3"]
}

Instruções:
- O abstract deve ser um parágrafo conciso que capture a essência do documento
- keyPoints devem ser os 3-5 pontos mais importantes do texto
- mainTopics devem ser os 3-5 temas principais abordados
- Use linguagem clara e objetiva
- Mantenha o foco no conteúdo mais relevante
`;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Tentar extrair JSON da resposta
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      throw new Error('Resposta não contém JSON válido');
    } catch (error) {
      console.error('Erro ao gerar resumo:', error);
      throw new Error(`Falha ao gerar resumo: ${error.message}`);
    }
  }

  async extractConcepts(text: string): Promise<ConceptData[]> {
    const prompt = `
Analise o seguinte texto e extraia os conceitos-chave mais importantes.

Texto para análise:
${text}

Retorne APENAS um array JSON válido com a seguinte estrutura:
[
  {
    "name": "Nome do conceito",
    "category": "person|place|theory|formula|term|other",
    "description": "Descrição clara e concisa do conceito",
    "importance": "high|medium|low"
  }
]

Instruções:
- Extraia entre 5-15 conceitos mais relevantes
- Categorize cada conceito apropriadamente:
  * person: pessoas, autores, figuras históricas
  * place: locais, países, instituições
  * theory: teorias, modelos, frameworks
  * formula: fórmulas matemáticas, equações
  * term: termos técnicos, definições
  * other: outros conceitos importantes
- A descrição deve ser clara e informativa (1-2 frases)
- Avalie a importância baseada na relevância no texto
- Foque nos conceitos mais significativos e únicos
`;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Tentar extrair JSON da resposta
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      throw new Error('Resposta não contém JSON válido');
    } catch (error) {
      console.error('Erro ao extrair conceitos:', error);
      throw new Error(`Falha ao extrair conceitos: ${error.message}`);
    }
  }

  async generateQA(text: string): Promise<QAData[]> {
    const prompt = `
Analise o seguinte texto e gere perguntas e respostas educativas baseadas no conteúdo.

Texto para análise:
${text}

Retorne APENAS um array JSON válido com a seguinte estrutura:
[
  {
    "question": "Pergunta clara e específica sobre o conteúdo",
    "answer": "Resposta completa e informativa",
    "difficulty": "easy|medium|hard",
    "category": "Categoria temática da pergunta"
  }
]

Instruções:
- Gere entre 5-10 perguntas de qualidade
- As perguntas devem cobrir diferentes aspectos do texto
- Varie a dificuldade: algumas básicas, algumas intermediárias, algumas avançadas
- As respostas devem ser completas mas concisas
- A categoria deve refletir o tema da pergunta (ex: "Conceitos Básicos", "Aplicação Prática", "Análise Crítica")
- Foque em perguntas que ajudem na compreensão e revisão do material
- Evite perguntas muito óbvias ou muito obscuras
`;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Tentar extrair JSON da resposta
      const jsonMatch = text.match(/\[[\s\S]*\]/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      throw new Error('Resposta não contém JSON válido');
    } catch (error) {
      console.error('Erro ao gerar Q&A:', error);
      throw new Error(`Falha ao gerar perguntas e respostas: ${error.message}`);
    }
  }

  async analyzeTextStructure(text: string): Promise<any> {
    const prompt = `
Analise a estrutura do seguinte texto e identifique elementos que poderiam ser representados visualmente.

Texto para análise:
${text}

Retorne APENAS um objeto JSON válido com a seguinte estrutura:
{
  "hasTimeline": boolean,
  "hasProcess": boolean,
  "hasHierarchy": boolean,
  "hasComparison": boolean,
  "hasStatistics": boolean,
  "suggestedDiagrams": ["tipo1", "tipo2"],
  "structuralElements": {
    "sections": ["Seção 1", "Seção 2"],
    "keyTerms": ["termo1", "termo2"],
    "relationships": ["relação1", "relação2"]
  }
}

Instruções:
- Identifique se o texto contém elementos temporais (timeline)
- Verifique se há processos ou fluxos de trabalho (process)
- Detecte estruturas hierárquicas (hierarchy)
- Identifique comparações ou contrastes (comparison)
- Procure por dados estatísticos ou numéricos (statistics)
- Sugira tipos de diagramas Mermaid apropriados: flowchart, timeline, mindmap, pie, etc.
- Liste as principais seções ou divisões do texto
- Identifique termos-chave que aparecem frequentemente
- Detecte relações importantes entre conceitos
`;

    try {
      const result = await this.model.generateContent(prompt);
      const response = await result.response;
      const text = response.text();
      
      // Tentar extrair JSON da resposta
      const jsonMatch = text.match(/\{[\s\S]*\}/);
      if (jsonMatch) {
        return JSON.parse(jsonMatch[0]);
      }
      
      throw new Error('Resposta não contém JSON válido');
    } catch (error) {
      console.error('Erro ao analisar estrutura:', error);
      throw new Error(`Falha ao analisar estrutura do texto: ${error.message}`);
    }
  }

  // Método para testar a conexão com a API
  async testConnection(): Promise<boolean> {
    try {
      const result = await this.model.generateContent('Responda apenas "OK" se você conseguir me ouvir.');
      const response = await result.response;
      const text = response.text();
      return text.toLowerCase().includes('ok');
    } catch (error) {
      console.error('Erro ao testar conexão:', error);
      return false;
    }
  }

  // Método para validar chave da API
  static async validateApiKey(apiKey: string): Promise<boolean> {
    try {
      const client = new GeminiClient(apiKey);
      return await client.testConnection();
    } catch (error) {
      return false;
    }
  }
}

