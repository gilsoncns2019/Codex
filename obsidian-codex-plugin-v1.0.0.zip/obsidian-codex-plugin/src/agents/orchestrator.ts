import { GeminiClient } from './geminiClient';
import { IngestionAgent } from './ingestionAgent';
import { MarkdownFormatter } from '../utils/markdownFormatter';
import { ProcessedContent, PDFContent, ProcessingProgress, CodexSettings } from '../types';

export class AgentOrchestrator {
  private geminiClient: GeminiClient;
  private ingestionAgent: IngestionAgent;
  private markdownFormatter: MarkdownFormatter;
  private settings: CodexSettings;
  private progressCallback?: (progress: ProcessingProgress) => void;

  constructor(settings: CodexSettings, progressCallback?: (progress: ProcessingProgress) => void) {
    this.settings = settings;
    this.progressCallback = progressCallback;
    
    this.geminiClient = new GeminiClient(settings.geminiApiKey, settings.geminiModel);
    this.ingestionAgent = new IngestionAgent();
    this.markdownFormatter = new MarkdownFormatter(settings);
  }

  async processPDF(arrayBuffer: ArrayBuffer, filename: string): Promise<{ content: string; filename: string }> {
    try {
      // Fase 1: Ingestão do PDF
      this.updateProgress('ingestion', 'Extraindo texto do PDF...', 10);
      const pdfContent = await this.ingestionAgent.extractPDFContent(arrayBuffer);
      
      if (!pdfContent.text || pdfContent.text.trim().length === 0) {
        throw new Error('Não foi possível extrair texto do PDF. O arquivo pode estar corrompido ou ser baseado em imagens.');
      }

      // Fase 2: Análise e processamento com IA
      this.updateProgress('analysis', 'Analisando conteúdo com IA...', 30);
      const processedContent = await this.analyzeContent(pdfContent);

      // Fase 3: Geração da nota em Markdown
      this.updateProgress('generation', 'Gerando nota em Markdown...', 80);
      const markdownNote = this.markdownFormatter.formatNote(processedContent, filename);

      this.updateProgress('complete', 'Processamento concluído!', 100);

      return {
        content: markdownNote.content,
        filename: markdownNote.filename
      };

    } catch (error) {
      this.updateProgress('error', `Erro no processamento: ${error.message}`, 0);
      throw error;
    }
  }

  private async analyzeContent(pdfContent: PDFContent): Promise<ProcessedContent> {
    const text = pdfContent.text;
    const results: Partial<ProcessedContent> = {
      originalText: text,
      metadata: pdfContent.metadata
    };

    try {
      // Executar análises em paralelo quando possível
      const analysisPromises: Promise<any>[] = [];

      // Resumo (sempre incluído se habilitado)
      if (this.settings.includeSummary) {
        analysisPromises.push(
          this.geminiClient.generateSummary(text)
            .then(summary => { results.summary = summary; })
            .catch(error => {
              console.warn('Erro ao gerar resumo:', error);
              results.summary = {
                abstract: 'Erro ao gerar resumo automaticamente.',
                keyPoints: [],
                mainTopics: []
              };
            })
        );
      }

      // Conceitos-chave
      if (this.settings.includeConcepts) {
        analysisPromises.push(
          this.geminiClient.extractConcepts(text)
            .then(concepts => { results.concepts = concepts; })
            .catch(error => {
              console.warn('Erro ao extrair conceitos:', error);
              results.concepts = [];
            })
        );
      }

      // Perguntas e respostas
      if (this.settings.includeQA) {
        analysisPromises.push(
          this.geminiClient.generateQA(text)
            .then(qa => { results.qa = qa; })
            .catch(error => {
              console.warn('Erro ao gerar Q&A:', error);
              results.qa = [];
            })
        );
      }

      // Aguardar todas as análises
      await Promise.all(analysisPromises);

      // Preencher valores padrão se necessário
      return {
        summary: results.summary || { abstract: '', keyPoints: [], mainTopics: [] },
        concepts: results.concepts || [],
        qa: results.qa || [],
        originalText: text,
        metadata: pdfContent.metadata
      };

    } catch (error) {
      console.error('Erro na análise de conteúdo:', error);
      throw new Error(`Falha na análise do conteúdo: ${error.message}`);
    }
  }

  private updateProgress(stage: ProcessingProgress['stage'], message: string, percentage: number) {
    if (this.progressCallback) {
      this.progressCallback({ stage, message, percentage });
    }
  }

  // Método para validar configurações antes do processamento
  async validateSettings(): Promise<{ valid: boolean; errors: string[] }> {
    const errors: string[] = [];

    // Validar chave da API
    if (!this.settings.geminiApiKey || this.settings.geminiApiKey.trim() === '') {
      errors.push('Chave da API Gemini não configurada');
    } else {
      try {
        const isValid = await GeminiClient.validateApiKey(this.settings.geminiApiKey);
        if (!isValid) {
          errors.push('Chave da API Gemini inválida ou sem acesso');
        }
      } catch (error) {
        errors.push('Erro ao validar chave da API Gemini');
      }
    }

    // Validar modelo
    if (!this.settings.geminiModel) {
      errors.push('Modelo Gemini não especificado');
    }

    // Validar pasta de saída
    if (!this.settings.outputFolder || this.settings.outputFolder.trim() === '') {
      errors.push('Pasta de saída não especificada');
    }

    return {
      valid: errors.length === 0,
      errors
    };
  }

  // Método para processar texto diretamente (útil para testes)
  async processText(text: string, filename: string = 'texto-processado'): Promise<{ content: string; filename: string }> {
    try {
      this.updateProgress('analysis', 'Analisando texto...', 20);

      const pdfContent: PDFContent = {
        text,
        metadata: {
          title: filename,
          pages: 1
        }
      };

      const processedContent = await this.analyzeContent(pdfContent);
      
      this.updateProgress('generation', 'Gerando nota...', 80);
      const markdownNote = this.markdownFormatter.formatNote(processedContent, filename);

      this.updateProgress('complete', 'Processamento concluído!', 100);

      return {
        content: markdownNote.content,
        filename: markdownNote.filename
      };

    } catch (error) {
      this.updateProgress('error', `Erro no processamento: ${error.message}`, 0);
      throw error;
    }
  }
}

