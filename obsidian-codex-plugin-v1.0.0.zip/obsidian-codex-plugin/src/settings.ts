import { App, PluginSettingTab, Setting } from 'obsidian';
import CodexPlugin from './main';
import { CodexSettings } from './types';

export const DEFAULT_SETTINGS: CodexSettings = {
  geminiApiKey: '',
  geminiModel: 'gemini-2.5-flash',
  enableOCR: false,
  ocrProvider: 'tesseract',
  outputFolder: 'Codex Generated Notes',
  includeQA: true,
  includeConcepts: true,
  includeSummary: true,
  includeMermaidDiagrams: true,
  includeLatex: true,
  includeIcons: true,
};

export class CodexSettingTab extends PluginSettingTab {
  plugin: CodexPlugin;

  constructor(app: App, plugin: CodexPlugin) {
    super(app, plugin);
    this.plugin = plugin;
  }

  display(): void {
    const { containerEl } = this;

    containerEl.empty();

    containerEl.createEl('h2', { text: 'Configurações do Codex' });

    // Seção API Gemini
    containerEl.createEl('h3', { text: 'Configuração da API Gemini' });

    new Setting(containerEl)
      .setName('Chave da API Gemini')
      .setDesc('Insira sua chave da API do Google Gemini. Você pode obter uma em https://makersuite.google.com/app/apikey')
      .addText(text => text
        .setPlaceholder('Insira sua chave da API')
        .setValue(this.plugin.settings.geminiApiKey)
        .onChange(async (value) => {
          this.plugin.settings.geminiApiKey = value;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('Modelo Gemini')
      .setDesc('Escolha o modelo Gemini a ser usado para processamento')
      .addDropdown(dropdown => dropdown
        .addOption('gemini-2.5-flash', 'Gemini 2.5 Flash (Recomendado)')
        .addOption('gemini-2.5-pro', 'Gemini 2.5 Pro (Mais Avançado)')
        .setValue(this.plugin.settings.geminiModel)
        .onChange(async (value) => {
          this.plugin.settings.geminiModel = value;
          await this.plugin.saveSettings();
        }));

    // Seção OCR
    containerEl.createEl('h3', { text: 'Configurações de OCR' });

    new Setting(containerEl)
      .setName('Habilitar OCR')
      .setDesc('Ativar reconhecimento óptico de caracteres para PDFs escaneados')
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.enableOCR)
        .onChange(async (value) => {
          this.plugin.settings.enableOCR = value;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('Provedor de OCR')
      .setDesc('Escolha entre processamento local (Tesseract) ou serviços em nuvem')
      .addDropdown(dropdown => dropdown
        .addOption('tesseract', 'Tesseract (Local)')
        .addOption('cloud', 'Serviços em Nuvem')
        .setValue(this.plugin.settings.ocrProvider)
        .onChange(async (value) => {
          this.plugin.settings.ocrProvider = value as 'tesseract' | 'cloud';
          await this.plugin.saveSettings();
        }));

    // Seção Saída
    containerEl.createEl('h3', { text: 'Configurações de Saída' });

    new Setting(containerEl)
      .setName('Pasta de Saída')
      .setDesc('Pasta onde as notas geradas serão salvas')
      .addText(text => text
        .setPlaceholder('Codex Generated Notes')
        .setValue(this.plugin.settings.outputFolder)
        .onChange(async (value) => {
          this.plugin.settings.outputFolder = value;
          await this.plugin.saveSettings();
        }));

    // Seção Conteúdo
    containerEl.createEl('h3', { text: 'Conteúdo das Notas' });

    new Setting(containerEl)
      .setName('Incluir Resumo')
      .setDesc('Gerar resumo do documento')
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.includeSummary)
        .onChange(async (value) => {
          this.plugin.settings.includeSummary = value;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('Incluir Conceitos-Chave')
      .setDesc('Extrair e listar conceitos importantes')
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.includeConcepts)
        .onChange(async (value) => {
          this.plugin.settings.includeConcepts = value;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('Incluir Perguntas e Respostas')
      .setDesc('Gerar perguntas e respostas baseadas no conteúdo')
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.includeQA)
        .onChange(async (value) => {
          this.plugin.settings.includeQA = value;
          await this.plugin.saveSettings();
        }));

    // Seção Formatação
    containerEl.createEl('h3', { text: 'Formatação Avançada' });

    new Setting(containerEl)
      .setName('Incluir Diagramas Mermaid')
      .setDesc('Gerar diagramas Mermaid quando apropriado')
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.includeMermaidDiagrams)
        .onChange(async (value) => {
          this.plugin.settings.includeMermaidDiagrams = value;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('Incluir Fórmulas LaTeX')
      .setDesc('Formatar equações matemáticas em LaTeX')
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.includeLatex)
        .onChange(async (value) => {
          this.plugin.settings.includeLatex = value;
          await this.plugin.saveSettings();
        }));

    new Setting(containerEl)
      .setName('Incluir Ícones')
      .setDesc('Adicionar ícones às notas (requer plugin Iconize)')
      .addToggle(toggle => toggle
        .setValue(this.plugin.settings.includeIcons)
        .onChange(async (value) => {
          this.plugin.settings.includeIcons = value;
          await this.plugin.saveSettings();
        }));
  }
}

