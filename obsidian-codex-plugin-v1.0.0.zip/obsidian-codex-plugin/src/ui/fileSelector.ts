import { Modal, App, TFile, Notice } from 'obsidian';
import { IngestionAgent } from '../agents/ingestionAgent';

export class FileSelectorModal extends Modal {
  private onFileSelected: (file: File | TFile) => void;
  private dragCounter: number = 0;

  constructor(app: App, onFileSelected: (file: File | TFile) => void) {
    super(app);
    this.onFileSelected = onFileSelected;
  }

  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass('codex-file-selector');

    // Título
    contentEl.createEl('h2', { 
      text: 'Selecionar PDF para Processamento',
      cls: 'codex-selector-title'
    });

    // Área de drag & drop
    const dropZone = contentEl.createDiv('codex-drop-zone');
    this.setupDropZone(dropZone);

    // Botão de seleção de arquivo
    const buttonContainer = contentEl.createDiv('codex-button-container');
    
    const selectButton = buttonContainer.createEl('button', {
      text: 'Escolher Arquivo PDF',
      cls: 'mod-cta codex-select-button'
    });
    
    selectButton.addEventListener('click', () => {
      this.openFileDialog();
    });

    // Lista de PDFs existentes no vault
    this.createVaultPDFList(contentEl);

    // Botões de ação
    const actionContainer = contentEl.createDiv('codex-action-container');
    
    const cancelButton = actionContainer.createEl('button', {
      text: 'Cancelar',
      cls: 'codex-cancel-button'
    });
    
    cancelButton.addEventListener('click', () => {
      this.close();
    });

    // Aplicar estilos
    this.applyStyles();
  }

  private setupDropZone(dropZone: HTMLElement) {
    // Conteúdo da zona de drop
    const dropIcon = dropZone.createDiv('codex-drop-icon');
    dropIcon.innerHTML = '📄';
    
    const dropText = dropZone.createDiv('codex-drop-text');
    dropText.innerHTML = `
      <div class="codex-drop-primary">Arraste um arquivo PDF aqui</div>
      <div class="codex-drop-secondary">ou clique no botão abaixo para selecionar</div>
    `;

    // Event listeners para drag & drop
    dropZone.addEventListener('dragenter', (e) => {
      e.preventDefault();
      this.dragCounter++;
      dropZone.addClass('codex-drag-over');
    });

    dropZone.addEventListener('dragleave', (e) => {
      e.preventDefault();
      this.dragCounter--;
      if (this.dragCounter === 0) {
        dropZone.removeClass('codex-drag-over');
      }
    });

    dropZone.addEventListener('dragover', (e) => {
      e.preventDefault();
    });

    dropZone.addEventListener('drop', (e) => {
      e.preventDefault();
      this.dragCounter = 0;
      dropZone.removeClass('codex-drag-over');
      
      const files = Array.from(e.dataTransfer?.files || []);
      const pdfFile = files.find(file => file.type === 'application/pdf' || file.name.toLowerCase().endsWith('.pdf'));
      
      if (pdfFile) {
        this.handleFileSelection(pdfFile);
      } else {
        new Notice('Por favor, selecione um arquivo PDF válido.');
      }
    });

    // Click para abrir dialog
    dropZone.addEventListener('click', () => {
      this.openFileDialog();
    });
  }

  private async createVaultPDFList(container: HTMLElement) {
    const pdfFiles = this.app.vault.getFiles().filter(file => file.extension === 'pdf');
    
    if (pdfFiles.length === 0) {
      return;
    }

    const listContainer = container.createDiv('codex-vault-pdfs');
    listContainer.createEl('h3', { 
      text: 'PDFs no Vault',
      cls: 'codex-vault-title'
    });

    const fileList = listContainer.createDiv('codex-file-list');

    for (const file of pdfFiles.slice(0, 10)) { // Limitar a 10 arquivos
      const fileItem = fileList.createDiv('codex-file-item');
      
      // Ícone do arquivo
      const fileIcon = fileItem.createDiv('codex-file-icon');
      fileIcon.innerHTML = '📄';
      
      // Informações do arquivo
      const fileInfo = fileItem.createDiv('codex-file-info');
      
      const fileName = fileInfo.createDiv('codex-file-name');
      fileName.textContent = file.name;
      
      const fileDetails = fileInfo.createDiv('codex-file-details');
      
      try {
        const stat = await this.app.vault.adapter.stat(file.path);
        const size = this.formatFileSize(stat?.size || 0);
        const date = new Date(stat?.mtime || 0).toLocaleDateString('pt-BR');
        fileDetails.textContent = `${size} • ${date}`;
      } catch (error) {
        fileDetails.textContent = 'Informações não disponíveis';
      }

      // Botão de seleção
      const selectBtn = fileItem.createEl('button', {
        text: 'Processar',
        cls: 'codex-file-select-btn'
      });
      
      selectBtn.addEventListener('click', () => {
        this.handleFileSelection(file);
      });

      fileItem.addEventListener('click', (e) => {
        if (e.target !== selectBtn) {
          this.handleFileSelection(file);
        }
      });
    }

    if (pdfFiles.length > 10) {
      const moreInfo = listContainer.createDiv('codex-more-info');
      moreInfo.textContent = `... e mais ${pdfFiles.length - 10} arquivos PDF`;
    }
  }

  private openFileDialog() {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.pdf,application/pdf';
    input.onchange = (e) => {
      const file = (e.target as HTMLInputElement).files?.[0];
      if (file) {
        this.handleFileSelection(file);
      }
    };
    input.click();
  }

  private async handleFileSelection(file: File | TFile) {
    // Validar se é um PDF
    let isValid = false;
    
    try {
      if (file instanceof File) {
        const arrayBuffer = await file.arrayBuffer();
        isValid = await IngestionAgent.validatePDF(arrayBuffer);
      } else {
        const arrayBuffer = await this.app.vault.readBinary(file);
        isValid = await IngestionAgent.validatePDF(arrayBuffer);
      }
    } catch (error) {
      new Notice('Erro ao validar o arquivo PDF.');
      return;
    }

    if (!isValid) {
      new Notice('O arquivo selecionado não é um PDF válido.');
      return;
    }

    // Mostrar preview se possível
    await this.showFilePreview(file);
  }

  private async showFilePreview(file: File | TFile) {
    const previewContainer = this.contentEl.createDiv('codex-file-preview');
    previewContainer.innerHTML = `
      <div class="codex-preview-header">
        <h3>Preview do Arquivo</h3>
      </div>
      <div class="codex-preview-content">
        <div class="codex-preview-loading">Carregando informações...</div>
      </div>
    `;

    try {
      let arrayBuffer: ArrayBuffer;
      let fileName: string;

      if (file instanceof File) {
        arrayBuffer = await file.arrayBuffer();
        fileName = file.name;
      } else {
        arrayBuffer = await this.app.vault.readBinary(file);
        fileName = file.name;
      }

      const info = await IngestionAgent.getPDFInfo(arrayBuffer);
      
      const previewContent = previewContainer.querySelector('.codex-preview-content') as HTMLElement;
      previewContent.innerHTML = `
        <div class="codex-preview-info">
          <div class="codex-info-item">
            <span class="codex-info-label">Nome:</span>
            <span class="codex-info-value">${fileName}</span>
          </div>
          <div class="codex-info-item">
            <span class="codex-info-label">Páginas:</span>
            <span class="codex-info-value">${info.pages}</span>
          </div>
          ${info.title ? `
            <div class="codex-info-item">
              <span class="codex-info-label">Título:</span>
              <span class="codex-info-value">${info.title}</span>
            </div>
          ` : ''}
          ${info.author ? `
            <div class="codex-info-item">
              <span class="codex-info-label">Autor:</span>
              <span class="codex-info-value">${info.author}</span>
            </div>
          ` : ''}
        </div>
        <div class="codex-preview-actions">
          <button class="mod-cta codex-confirm-btn">Processar Este Arquivo</button>
          <button class="codex-back-btn">Escolher Outro</button>
        </div>
      `;

      // Event listeners para os botões
      const confirmBtn = previewContent.querySelector('.codex-confirm-btn') as HTMLElement;
      const backBtn = previewContent.querySelector('.codex-back-btn') as HTMLElement;

      confirmBtn.addEventListener('click', () => {
        this.onFileSelected(file);
        this.close();
      });

      backBtn.addEventListener('click', () => {
        previewContainer.remove();
      });

    } catch (error) {
      const previewContent = previewContainer.querySelector('.codex-preview-content') as HTMLElement;
      previewContent.innerHTML = `
        <div class="codex-preview-error">
          Erro ao carregar informações do arquivo.
          <button class="mod-cta codex-confirm-btn">Processar Mesmo Assim</button>
        </div>
      `;

      const confirmBtn = previewContent.querySelector('.codex-confirm-btn') as HTMLElement;
      confirmBtn.addEventListener('click', () => {
        this.onFileSelected(file);
        this.close();
      });
    }
  }

  private formatFileSize(bytes: number): string {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(1)) + ' ' + sizes[i];
  }

  private applyStyles() {
    const style = document.createElement('style');
    style.textContent = `
      .codex-file-selector {
        padding: 20px;
        min-width: 500px;
        max-width: 600px;
        max-height: 80vh;
        overflow-y: auto;
      }

      .codex-selector-title {
        text-align: center;
        margin-bottom: 20px;
        color: var(--text-normal);
      }

      .codex-drop-zone {
        border: 2px dashed var(--background-modifier-border);
        border-radius: 8px;
        padding: 40px 20px;
        text-align: center;
        cursor: pointer;
        transition: all 0.3s ease;
        margin-bottom: 20px;
      }

      .codex-drop-zone:hover,
      .codex-drop-zone.codex-drag-over {
        border-color: var(--interactive-accent);
        background-color: var(--background-modifier-hover);
      }

      .codex-drop-icon {
        font-size: 3em;
        margin-bottom: 10px;
      }

      .codex-drop-primary {
        font-size: 1.1em;
        font-weight: 600;
        margin-bottom: 5px;
        color: var(--text-normal);
      }

      .codex-drop-secondary {
        font-size: 0.9em;
        color: var(--text-muted);
      }

      .codex-button-container {
        text-align: center;
        margin-bottom: 20px;
      }

      .codex-select-button {
        padding: 10px 20px;
        font-size: 1em;
      }

      .codex-vault-pdfs {
        margin-bottom: 20px;
      }

      .codex-vault-title {
        margin-bottom: 10px;
        color: var(--text-normal);
        font-size: 1em;
      }

      .codex-file-list {
        max-height: 200px;
        overflow-y: auto;
        border: 1px solid var(--background-modifier-border);
        border-radius: 4px;
      }

      .codex-file-item {
        display: flex;
        align-items: center;
        padding: 10px;
        border-bottom: 1px solid var(--background-modifier-border);
        cursor: pointer;
        transition: background-color 0.2s ease;
      }

      .codex-file-item:hover {
        background-color: var(--background-modifier-hover);
      }

      .codex-file-item:last-child {
        border-bottom: none;
      }

      .codex-file-icon {
        font-size: 1.5em;
        margin-right: 10px;
      }

      .codex-file-info {
        flex: 1;
      }

      .codex-file-name {
        font-weight: 500;
        margin-bottom: 2px;
      }

      .codex-file-details {
        font-size: 0.8em;
        color: var(--text-muted);
      }

      .codex-file-select-btn {
        padding: 5px 10px;
        font-size: 0.8em;
        border-radius: 4px;
      }

      .codex-more-info {
        text-align: center;
        padding: 10px;
        font-size: 0.9em;
        color: var(--text-muted);
        font-style: italic;
      }

      .codex-action-container {
        text-align: center;
        margin-top: 20px;
      }

      .codex-file-preview {
        margin-top: 20px;
        border: 1px solid var(--background-modifier-border);
        border-radius: 8px;
        padding: 15px;
        background-color: var(--background-secondary);
      }

      .codex-preview-header h3 {
        margin: 0 0 15px 0;
        color: var(--text-normal);
      }

      .codex-preview-loading {
        text-align: center;
        color: var(--text-muted);
        padding: 20px;
      }

      .codex-preview-info {
        margin-bottom: 15px;
      }

      .codex-info-item {
        display: flex;
        margin-bottom: 8px;
      }

      .codex-info-label {
        font-weight: 600;
        min-width: 80px;
        color: var(--text-muted);
      }

      .codex-info-value {
        color: var(--text-normal);
      }

      .codex-preview-actions {
        display: flex;
        gap: 10px;
        justify-content: center;
      }

      .codex-preview-error {
        text-align: center;
        color: var(--text-error);
        padding: 20px;
      }

      .codex-confirm-btn {
        padding: 8px 16px;
      }

      .codex-back-btn {
        padding: 8px 16px;
        background: transparent;
        border: 1px solid var(--background-modifier-border);
      }
    `;
    
    document.head.appendChild(style);
  }

  onClose() {
    const { contentEl } = this;
    contentEl.empty();
  }
}

