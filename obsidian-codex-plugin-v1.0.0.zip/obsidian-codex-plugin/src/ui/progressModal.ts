import { Modal, App, Setting } from 'obsidian';
import { ProcessingProgress } from '../types';

export class ProgressModal extends Modal {
  private progressBar: HTMLElement;
  private statusText: HTMLElement;
  private currentStage: HTMLElement;
  private cancelCallback?: () => void;
  private isComplete: boolean = false;

  constructor(app: App, cancelCallback?: () => void) {
    super(app);
    this.cancelCallback = cancelCallback;
  }

  onOpen() {
    const { contentEl } = this;
    contentEl.empty();
    contentEl.addClass('codex-progress-modal');

    // Título
    contentEl.createEl('h2', { 
      text: 'Processando PDF com Codex',
      cls: 'codex-modal-title'
    });

    // Container do progresso
    const progressContainer = contentEl.createDiv('codex-progress-container');

    // Indicador de estágio atual
    this.currentStage = progressContainer.createEl('div', {
      cls: 'codex-current-stage',
      text: 'Iniciando processamento...'
    });

    // Barra de progresso
    const progressWrapper = progressContainer.createDiv('codex-progress-wrapper');
    const progressTrack = progressWrapper.createDiv('codex-progress-track');
    this.progressBar = progressTrack.createDiv('codex-progress-bar');

    // Texto de status
    this.statusText = progressContainer.createEl('div', {
      cls: 'codex-status-text',
      text: 'Preparando para processar o documento...'
    });

    // Indicadores de etapas
    const stagesContainer = progressContainer.createDiv('codex-stages-container');
    this.createStageIndicators(stagesContainer);

    // Botões
    const buttonContainer = contentEl.createDiv('codex-button-container');
    
    if (this.cancelCallback) {
      const cancelButton = buttonContainer.createEl('button', {
        text: 'Cancelar',
        cls: 'mod-cta codex-cancel-button'
      });
      
      cancelButton.addEventListener('click', () => {
        if (!this.isComplete && this.cancelCallback) {
          this.cancelCallback();
        }
        this.close();
      });
    }

    // Aplicar estilos
    this.applyStyles();
  }

  private createStageIndicators(container: HTMLElement) {
    const stages = [
      { id: 'ingestion', label: 'Extração', icon: '📄' },
      { id: 'analysis', label: 'Análise IA', icon: '🧠' },
      { id: 'generation', label: 'Geração', icon: '✍️' },
      { id: 'complete', label: 'Concluído', icon: '✅' }
    ];

    stages.forEach(stage => {
      const stageEl = container.createDiv('codex-stage-indicator');
      stageEl.setAttribute('data-stage', stage.id);
      
      const iconEl = stageEl.createSpan('codex-stage-icon');
      iconEl.textContent = stage.icon;
      
      const labelEl = stageEl.createSpan('codex-stage-label');
      labelEl.textContent = stage.label;
    });
  }

  updateProgress(progress: ProcessingProgress) {
    // Atualizar barra de progresso
    this.progressBar.style.width = `${progress.percentage}%`;
    
    // Atualizar texto de status
    this.statusText.textContent = progress.message;
    
    // Atualizar estágio atual
    const stageLabels = {
      'ingestion': 'Extraindo texto do PDF',
      'analysis': 'Analisando conteúdo com IA',
      'generation': 'Gerando nota estruturada',
      'complete': 'Processamento concluído',
      'error': 'Erro no processamento'
    };
    
    this.currentStage.textContent = stageLabels[progress.stage] || progress.message;
    
    // Atualizar indicadores visuais
    this.updateStageIndicators(progress.stage);
    
    // Marcar como completo se necessário
    if (progress.stage === 'complete') {
      this.isComplete = true;
      this.showCompletionState();
    } else if (progress.stage === 'error') {
      this.showErrorState(progress.message);
    }
  }

  private updateStageIndicators(currentStage: string) {
    const stageOrder = ['ingestion', 'analysis', 'generation', 'complete'];
    const currentIndex = stageOrder.indexOf(currentStage);
    
    const indicators = this.contentEl.querySelectorAll('.codex-stage-indicator');
    indicators.forEach((indicator, index) => {
      indicator.removeClass('active', 'completed');
      
      if (index < currentIndex) {
        indicator.addClass('completed');
      } else if (index === currentIndex) {
        indicator.addClass('active');
      }
    });
  }

  private showCompletionState() {
    // Atualizar botão de cancelar para "Fechar"
    const cancelButton = this.contentEl.querySelector('.codex-cancel-button') as HTMLElement;
    if (cancelButton) {
      cancelButton.textContent = 'Fechar';
      cancelButton.removeClass('codex-cancel-button');
      cancelButton.addClass('codex-close-button');
    }

    // Adicionar classe de sucesso
    this.contentEl.addClass('codex-success');
    
    // Auto-fechar após 3 segundos
    setTimeout(() => {
      if (!this.contentEl.hasClass('codex-manual-close')) {
        this.close();
      }
    }, 3000);
  }

  private showErrorState(errorMessage: string) {
    this.contentEl.addClass('codex-error');
    this.statusText.textContent = errorMessage;
    this.currentStage.textContent = 'Erro no processamento';
    
    // Atualizar botão
    const cancelButton = this.contentEl.querySelector('.codex-cancel-button') as HTMLElement;
    if (cancelButton) {
      cancelButton.textContent = 'Fechar';
    }
  }

  private applyStyles() {
    // Adicionar estilos CSS inline (será movido para arquivo CSS separado)
    const style = document.createElement('style');
    style.textContent = `
      .codex-progress-modal {
        padding: 20px;
        min-width: 400px;
        max-width: 500px;
      }

      .codex-modal-title {
        text-align: center;
        margin-bottom: 20px;
        color: var(--text-normal);
        font-size: 1.2em;
      }

      .codex-progress-container {
        margin-bottom: 20px;
      }

      .codex-current-stage {
        font-weight: 600;
        margin-bottom: 10px;
        color: var(--text-accent);
        text-align: center;
      }

      .codex-progress-wrapper {
        margin: 15px 0;
      }

      .codex-progress-track {
        width: 100%;
        height: 8px;
        background-color: var(--background-modifier-border);
        border-radius: 4px;
        overflow: hidden;
      }

      .codex-progress-bar {
        height: 100%;
        background: linear-gradient(90deg, var(--interactive-accent), var(--interactive-accent-hover));
        border-radius: 4px;
        transition: width 0.3s ease;
        width: 0%;
      }

      .codex-status-text {
        font-size: 0.9em;
        color: var(--text-muted);
        text-align: center;
        margin-top: 10px;
        min-height: 1.2em;
      }

      .codex-stages-container {
        display: flex;
        justify-content: space-between;
        margin: 20px 0;
        padding: 0 10px;
      }

      .codex-stage-indicator {
        display: flex;
        flex-direction: column;
        align-items: center;
        opacity: 0.5;
        transition: opacity 0.3s ease;
      }

      .codex-stage-indicator.active {
        opacity: 1;
        color: var(--interactive-accent);
      }

      .codex-stage-indicator.completed {
        opacity: 1;
        color: var(--text-success);
      }

      .codex-stage-icon {
        font-size: 1.5em;
        margin-bottom: 5px;
      }

      .codex-stage-label {
        font-size: 0.8em;
        text-align: center;
      }

      .codex-button-container {
        display: flex;
        justify-content: center;
        margin-top: 20px;
      }

      .codex-cancel-button, .codex-close-button {
        padding: 8px 16px;
        border-radius: 4px;
        border: none;
        cursor: pointer;
        transition: background-color 0.2s ease;
      }

      .codex-success .codex-progress-bar {
        background: linear-gradient(90deg, var(--text-success), var(--text-success));
      }

      .codex-error .codex-progress-bar {
        background: linear-gradient(90deg, var(--text-error), var(--text-error));
      }

      .codex-error .codex-current-stage {
        color: var(--text-error);
      }

      @keyframes pulse {
        0% { opacity: 1; }
        50% { opacity: 0.7; }
        100% { opacity: 1; }
      }

      .codex-stage-indicator.active .codex-stage-icon {
        animation: pulse 1.5s infinite;
      }
    `;
    
    document.head.appendChild(style);
  }

  onClose() {
    // Marcar como fechamento manual para evitar auto-close
    this.contentEl.addClass('codex-manual-close');
    
    const { contentEl } = this;
    contentEl.empty();
  }
}

