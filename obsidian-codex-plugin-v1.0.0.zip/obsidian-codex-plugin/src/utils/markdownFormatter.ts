import { ProcessedContent, MarkdownNote, ConceptData, QAData, SummaryData } from '../types';
import { DiagramGenerator } from './diagramGenerator';
import { LatexFormatter } from './latexFormatter';

export class MarkdownFormatter {
  private settings: any;
  private diagramGenerator: DiagramGenerator;
  private latexFormatter: LatexFormatter;

  constructor(settings: any) {
    this.settings = settings;
    this.diagramGenerator = new DiagramGenerator();
    this.latexFormatter = new LatexFormatter();
  }

  formatNote(content: ProcessedContent, originalFilename: string): MarkdownNote {
    const title = this.extractTitle(content, originalFilename);
    const filename = this.generateFilename(title);
    const frontmatter = this.generateFrontmatter(content, originalFilename);
    const markdownContent = this.generateMarkdownContent(content, title);

    return {
      title,
      content: markdownContent,
      frontmatter,
      filename
    };
  }

  private extractTitle(content: ProcessedContent, originalFilename: string): string {
    // Tentar extrair título dos metadados do PDF
    if (content.metadata.title && content.metadata.title.trim()) {
      return content.metadata.title.trim();
    }

    // Usar o nome do arquivo como fallback
    return originalFilename.replace('.pdf', '').replace(/[-_]/g, ' ');
  }

  private generateFilename(title: string): string {
    // Sanitizar título para nome de arquivo
    const sanitized = title
      .replace(/[^\w\s-]/g, '') // Remover caracteres especiais
      .replace(/\s+/g, '-') // Substituir espaços por hífens
      .toLowerCase();
    
    return `${sanitized}.md`;
  }

  private generateFrontmatter(content: ProcessedContent, originalFilename: string): Record<string, any> {
    const frontmatter: Record<string, any> = {
      tags: ['codex-generated', 'pdf-processed'],
      created: new Date().toISOString(),
      source: originalFilename,
      processed_by: 'Codex Plugin',
    };

    if (this.settings.includeIcons) {
      frontmatter.icon = 'fas-file-pdf';
    }

    if (content.metadata.author) {
      frontmatter.author = content.metadata.author;
    }

    if (content.metadata.creationDate) {
      frontmatter.original_date = content.metadata.creationDate.toISOString();
    }

    return frontmatter;
  }

  private generateMarkdownContent(content: ProcessedContent, title: string): string {
    let markdown = '';

    // Frontmatter
    const frontmatterYaml = this.frontmatterToYaml(this.generateFrontmatter(content, ''));
    markdown += `---\n${frontmatterYaml}---\n\n`;

    // Título principal
    if (this.settings.includeIcons) {
      markdown += `# ::fas-file-pdf:: ${title}\n\n`;
    } else {
      markdown += `# ${title}\n\n`;
    }

    // Metadados do documento
    markdown += this.formatMetadata(content.metadata);

    // Resumo
    if (this.settings.includeSummary && content.summary) {
      markdown += this.formatSummary(content.summary);
    }

    // Conceitos-chave
    if (this.settings.includeConcepts && content.concepts.length > 0) {
      markdown += this.formatConcepts(content.concepts);
    }

    // Fórmulas LaTeX (se habilitado e há conteúdo matemático)
    if (this.settings.includeLatex && LatexFormatter.hasMathContent(content.originalText)) {
      const latexSection = this.latexFormatter.generateEquationBlocks(content.concepts);
      if (latexSection) {
        markdown += latexSection;
      }
    }

    // Perguntas e Respostas
    if (this.settings.includeQA && content.qa.length > 0) {
      markdown += this.formatQA(content.qa);
    }

    // Diagramas Mermaid
    if (this.settings.includeMermaidDiagrams && content.concepts.length > 0) {
      markdown += this.generateDiagrams(content, title);
    }

    // Aplicar formatação LaTeX no texto (se habilitado)
    if (this.settings.includeLatex) {
      markdown = this.latexFormatter.formatMathExpressions(markdown);
    }

    return markdown;
  }

  private frontmatterToYaml(frontmatter: Record<string, any>): string {
    return Object.entries(frontmatter)
      .map(([key, value]) => {
        if (Array.isArray(value)) {
          return `${key}:\n${value.map(v => `  - ${v}`).join('\n')}`;
        }
        return `${key}: ${JSON.stringify(value)}`;
      })
      .join('\n');
  }

  private formatMetadata(metadata: any): string {
    let section = '';

    if (this.settings.includeIcons) {
      section += `## ::fas-info-circle:: Informações do Documento\n\n`;
    } else {
      section += `## Informações do Documento\n\n`;
    }

    const metadataTable = [
      '| Campo | Valor |',
      '|-------|-------|'
    ];

    if (metadata.author) metadataTable.push(`| **Autor** | ${metadata.author} |`);
    if (metadata.subject) metadataTable.push(`| **Assunto** | ${metadata.subject} |`);
    if (metadata.creator) metadataTable.push(`| **Criador** | ${metadata.creator} |`);
    if (metadata.pages) metadataTable.push(`| **Páginas** | ${metadata.pages} |`);
    if (metadata.creationDate) metadataTable.push(`| **Data de Criação** | ${metadata.creationDate.toLocaleDateString('pt-BR')} |`);

    section += metadataTable.join('\n') + '\n\n';
    section += '---\n\n';

    return section;
  }

  private formatSummary(summary: SummaryData): string {
    let section = '';

    if (this.settings.includeIcons) {
      section += `## ::fas-clipboard-list:: Resumo\n\n`;
    } else {
      section += `## Resumo\n\n`;
    }

    section += `> [!ABSTRACT] Resumo Executivo\n`;
    section += `> ${summary.abstract}\n\n`;

    if (summary.keyPoints.length > 0) {
      section += `### Pontos-Chave\n\n`;
      summary.keyPoints.forEach(point => {
        section += `- **${point}**\n`;
      });
      section += '\n';
    }

    if (summary.mainTopics.length > 0) {
      section += `### Tópicos Principais\n\n`;
      summary.mainTopics.forEach(topic => {
        section += `- ${topic}\n`;
      });
      section += '\n';
    }

    section += '---\n\n';
    return section;
  }

  private formatConcepts(concepts: ConceptData[]): string {
    let section = '';

    if (this.settings.includeIcons) {
      section += `## ::fas-lightbulb:: Conceitos-Chave\n\n`;
    } else {
      section += `## Conceitos-Chave\n\n`;
    }

    // Agrupar conceitos por categoria
    const groupedConcepts = concepts.reduce((groups, concept) => {
      const category = concept.category;
      if (!groups[category]) {
        groups[category] = [];
      }
      groups[category].push(concept);
      return groups;
    }, {} as Record<string, ConceptData[]>);

    Object.entries(groupedConcepts).forEach(([category, categoryConceptsArray]) => {
      const categoryName = this.getCategoryDisplayName(category);
      section += `### ${categoryName}\n\n`;

      categoryConceptsArray.forEach(concept => {
        const importanceIcon = this.getImportanceIcon(concept.importance);
        section += `- **${concept.name}** ${importanceIcon}\n`;
        section += `  ${concept.description}\n\n`;
      });
    });

    section += '---\n\n';
    return section;
  }

  private formatQA(qaList: QAData[]): string {
    let section = '';

    if (this.settings.includeIcons) {
      section += `## ::fas-question-circle:: Perguntas e Respostas\n\n`;
    } else {
      section += `## Perguntas e Respostas\n\n`;
    }

    qaList.forEach((qa, index) => {
      const difficultyIcon = this.getDifficultyIcon(qa.difficulty);
      section += `### Questão ${index + 1} ${difficultyIcon}\n\n`;
      section += `**${qa.question}**\n\n`;
      section += `> [!SUCCESS] Resposta\n`;
      section += `> ${qa.answer}\n\n`;
      
      if (qa.category) {
        section += `*Categoria: ${qa.category}*\n\n`;
      }
      
      section += '---\n\n';
    });

    return section;
  }

  private generateDiagrams(content: ProcessedContent, title: string): string {
    let diagramsSection = '';

    // Determinar o melhor tipo de diagrama
    const suggestedType = this.diagramGenerator.suggestBestDiagram(content);

    if (this.settings.includeIcons) {
      diagramsSection += `## ::fas-project-diagram:: Visualizações\n\n`;
    } else {
      diagramsSection += `## Visualizações\n\n`;
    }

    // Gerar diagrama principal baseado na sugestão
    switch (suggestedType) {
      case 'timeline':
        const timeline = this.diagramGenerator.generateTimelineFromContent(content);
        if (timeline) {
          diagramsSection += `### Linha do Tempo\n\n${timeline}\n`;
        }
        break;
      
      case 'process':
        const process = this.diagramGenerator.generateProcessDiagram(content);
        if (process) {
          diagramsSection += `### Fluxo de Processo\n\n${process}\n`;
        }
        break;
      
      case 'flowchart':
        const flowchart = this.diagramGenerator.generateConceptFlowchart(content.concepts, title);
        if (flowchart) {
          diagramsSection += `### Fluxograma de Conceitos\n\n${flowchart}\n`;
        }
        break;
      
      default:
        const mindmap = this.diagramGenerator.generateConceptMindMap(content.concepts, title);
        if (mindmap) {
          diagramsSection += `### Mapa Mental\n\n${mindmap}\n`;
        }
    }

    // Adicionar diagrama de comparação se há conceitos suficientes
    if (content.concepts.length >= 5) {
      const comparison = this.diagramGenerator.generateComparisonChart(content.concepts);
      if (comparison) {
        diagramsSection += `### Análise Comparativa\n\n${comparison}\n`;
      }
    }

    diagramsSection += '---\n\n';
    return diagramsSection;
  }

  private getCategoryDisplayName(category: string): string {
    const categoryMap: Record<string, string> = {
      'person': 'Pessoas',
      'place': 'Lugares',
      'theory': 'Teorias',
      'formula': 'Fórmulas',
      'term': 'Termos',
      'other': 'Outros'
    };
    return categoryMap[category] || category;
  }

  private getImportanceIcon(importance: string): string {
    if (!this.settings.includeIcons) return '';
    
    const iconMap: Record<string, string> = {
      'high': '::fas-star::',
      'medium': '::fas-star-half-alt::',
      'low': '::far-star::'
    };
    return iconMap[importance] || '';
  }

  private getDifficultyIcon(difficulty: string): string {
    if (!this.settings.includeIcons) return '';
    
    const iconMap: Record<string, string> = {
      'easy': '::fas-smile::',
      'medium': '::fas-meh::',
      'hard': '::fas-frown::'
    };
    return iconMap[difficulty] || '';
  }
}

