export class LatexFormatter {
  
  // Detectar e formatar equações matemáticas no texto
  formatMathExpressions(text: string): string {
    let formattedText = text;

    // Padrões para detectar expressões matemáticas
    const mathPatterns = [
      // Equações com = (ex: E = mc²)
      {
        regex: /\b([A-Za-z]+)\s*=\s*([A-Za-z0-9²³⁴⁵⁶⁷⁸⁹⁰₁₂₃₄₅₆₇₈₉₀\+\-\*\/\(\)\s]+)/g,
        formatter: (match: string, variable: string, expression: string) => {
          return `$${variable} = ${this.convertToLatex(expression)}$`;
        }
      },
      
      // Frações (ex: 1/2, a/b)
      {
        regex: /\b(\w+)\/(\w+)\b/g,
        formatter: (match: string, numerator: string, denominator: string) => {
          return `$\\frac{${numerator}}{${denominator}}$`;
        }
      },
      
      // Potências com símbolos Unicode (ex: x², a³)
      {
        regex: /\b(\w+)([²³⁴⁵⁶⁷⁸⁹⁰]+)/g,
        formatter: (match: string, base: string, exponent: string) => {
          const latexExponent = this.convertUnicodeExponent(exponent);
          return `$${base}^{${latexExponent}}$`;
        }
      },
      
      // Índices com símbolos Unicode (ex: H₂O)
      {
        regex: /\b(\w+)([₁₂₃₄₅₆₇₈₉₀]+)/g,
        formatter: (match: string, base: string, subscript: string) => {
          const latexSubscript = this.convertUnicodeSubscript(subscript);
          return `$${base}_{${latexSubscript}}$`;
        }
      },
      
      // Raízes quadradas (ex: √x, √(a+b))
      {
        regex: /√\(([^)]+)\)|√(\w+)/g,
        formatter: (match: string, expression1?: string, expression2?: string) => {
          const expr = expression1 || expression2;
          return `$\\sqrt{${expr}}$`;
        }
      },
      
      // Símbolos matemáticos especiais
      {
        regex: /\b(sin|cos|tan|log|ln|exp)\s*\(([^)]+)\)/g,
        formatter: (match: string, func: string, arg: string) => {
          return `$\\${func}(${arg})$`;
        }
      }
    ];

    // Aplicar cada padrão
    mathPatterns.forEach(pattern => {
      formattedText = formattedText.replace(pattern.regex, pattern.formatter);
    });

    return formattedText;
  }

  // Gerar blocos de equações para fórmulas importantes
  generateEquationBlocks(concepts: any[]): string {
    const formulaConcepts = concepts.filter(c => c.category === 'formula');
    
    if (formulaConcepts.length === 0) return '';

    let latexSection = '\n## Fórmulas Principais\n\n';

    formulaConcepts.forEach(concept => {
      latexSection += `### ${concept.name}\n\n`;
      
      // Tentar extrair a fórmula da descrição
      const formula = this.extractFormulaFromDescription(concept.description);
      
      if (formula) {
        latexSection += `$$${formula}$$\n\n`;
      }
      
      latexSection += `${concept.description}\n\n`;
      latexSection += '---\n\n';
    });

    return latexSection;
  }

  // Converter expressões para LaTeX
  private convertToLatex(expression: string): string {
    let latex = expression;

    // Conversões básicas
    const conversions = [
      // Potências
      { from: /\^(\w+)/g, to: '^{$1}' },
      { from: /\*\*/g, to: '^' },
      
      // Multiplicação
      { from: /\*/g, to: ' \\cdot ' },
      
      // Divisão
      { from: /\/(\w+)/g, to: '/_{$1}' },
      
      // Símbolos especiais
      { from: /alpha/gi, to: '\\alpha' },
      { from: /beta/gi, to: '\\beta' },
      { from: /gamma/gi, to: '\\gamma' },
      { from: /delta/gi, to: '\\delta' },
      { from: /epsilon/gi, to: '\\epsilon' },
      { from: /theta/gi, to: '\\theta' },
      { from: /lambda/gi, to: '\\lambda' },
      { from: /mu/gi, to: '\\mu' },
      { from: /pi/gi, to: '\\pi' },
      { from: /sigma/gi, to: '\\sigma' },
      { from: /phi/gi, to: '\\phi' },
      { from: /omega/gi, to: '\\omega' },
      
      // Operadores
      { from: /\+\-/g, to: '\\pm' },
      { from: /-\+/g, to: '\\mp' },
      { from: /infinity/gi, to: '\\infty' },
      { from: /integral/gi, to: '\\int' },
      { from: /sum/gi, to: '\\sum' },
      { from: /product/gi, to: '\\prod' }
    ];

    conversions.forEach(conv => {
      latex = latex.replace(conv.from, conv.to);
    });

    return latex;
  }

  // Converter expoentes Unicode para LaTeX
  private convertUnicodeExponent(unicode: string): string {
    const exponentMap: Record<string, string> = {
      '²': '2', '³': '3', '⁴': '4', '⁵': '5', '⁶': '6',
      '⁷': '7', '⁸': '8', '⁹': '9', '⁰': '0', '¹': '1'
    };

    return unicode.split('').map(char => exponentMap[char] || char).join('');
  }

  // Converter índices Unicode para LaTeX
  private convertUnicodeSubscript(unicode: string): string {
    const subscriptMap: Record<string, string> = {
      '₀': '0', '₁': '1', '₂': '2', '₃': '3', '₄': '4',
      '₅': '5', '₆': '6', '₇': '7', '₈': '8', '₉': '9'
    };

    return unicode.split('').map(char => subscriptMap[char] || char).join('');
  }

  // Extrair fórmula da descrição do conceito
  private extractFormulaFromDescription(description: string): string | null {
    // Procurar por padrões que parecem fórmulas
    const formulaPatterns = [
      // Equações com =
      /([A-Za-z]+\s*=\s*[A-Za-z0-9²³⁴⁵⁶⁷⁸⁹⁰₁₂₃₄₅₆₇₈₉₀\+\-\*\/\(\)\s]+)/,
      // Expressões entre parênteses que parecem matemáticas
      /\(([A-Za-z0-9²³⁴⁵⁶⁷⁸⁹⁰₁₂₃₄₅₆₇₈₉₀\+\-\*\/\s]+)\)/,
      // Frações
      /(\w+\/\w+)/
    ];

    for (const pattern of formulaPatterns) {
      const match = description.match(pattern);
      if (match) {
        return this.convertToLatex(match[1]);
      }
    }

    return null;
  }

  // Detectar se o texto contém muitas expressões matemáticas
  static hasMathContent(text: string): boolean {
    const mathIndicators = [
      /\b\w+\s*=\s*\w+/g, // Equações
      /\b\w+[²³⁴⁵⁶⁷⁸⁹⁰]/g, // Potências
      /\b\w+[₁₂₃₄₅₆₇₈₉₀]/g, // Índices
      /√/g, // Raízes
      /\b(sin|cos|tan|log|ln|exp)\b/gi, // Funções matemáticas
      /\b(alpha|beta|gamma|delta|epsilon|theta|lambda|mu|pi|sigma|phi|omega)\b/gi, // Letras gregas
      /\b(integral|derivative|limit|sum|product)\b/gi // Termos matemáticos
    ];

    let mathCount = 0;
    mathIndicators.forEach(pattern => {
      const matches = text.match(pattern);
      if (matches) {
        mathCount += matches.length;
      }
    });

    // Se há mais de 3 indicadores matemáticos, provavelmente é conteúdo matemático
    return mathCount >= 3;
  }

  // Gerar snippets do LaTeX Suite para uso no Obsidian
  generateLatexSuiteSnippets(): string {
    return `
## Snippets Recomendados para LaTeX Suite

Para otimizar a escrita de LaTeX no Obsidian, adicione estes snippets ao plugin LaTeX Suite:

\`\`\`json
{
  "frac": "\\\\frac{$1}{$2}$0",
  "sqrt": "\\\\sqrt{$1}$0",
  "sum": "\\\\sum_{$1}^{$2} $0",
  "int": "\\\\int_{$1}^{$2} $3 \\\\, d$4$0",
  "lim": "\\\\lim_{$1 \\\\to $2} $0",
  "alpha": "\\\\alpha",
  "beta": "\\\\beta",
  "gamma": "\\\\gamma",
  "delta": "\\\\delta",
  "epsilon": "\\\\epsilon",
  "theta": "\\\\theta",
  "lambda": "\\\\lambda",
  "mu": "\\\\mu",
  "pi": "\\\\pi",
  "sigma": "\\\\sigma",
  "phi": "\\\\phi",
  "omega": "\\\\omega"
}
\`\`\`

Estes snippets aceleram significativamente a digitação de equações matemáticas.
`;
  }
}

