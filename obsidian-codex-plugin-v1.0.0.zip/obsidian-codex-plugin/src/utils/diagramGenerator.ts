import { ConceptData, ProcessedContent } from '../types';

export class DiagramGenerator {
  
  generateConceptMindMap(concepts: ConceptData[], title: string): string {
    if (concepts.length === 0) return '';

    let mermaid = '```mermaid\n';
    mermaid += 'mindmap\n';
    mermaid += `  root((${this.sanitizeForMermaid(title)}))\n`;

    // Agrupar conceitos por categoria
    const groupedConcepts = this.groupConceptsByCategory(concepts);

    Object.entries(groupedConcepts).forEach(([category, categoryConceptsArray]) => {
      const categoryName = this.getCategoryDisplayName(category);
      mermaid += `    ${this.sanitizeForMermaid(categoryName)}\n`;
      
      // Limitar a 5 conceitos por categoria para evitar diagramas muito complexos
      categoryConceptsArray.slice(0, 5).forEach(concept => {
        const cleanName = this.sanitizeForMermaid(concept.name);
        mermaid += `      ${cleanName}\n`;
      });
    });

    mermaid += '```\n';
    return mermaid;
  }

  generateConceptFlowchart(concepts: ConceptData[], title: string): string {
    if (concepts.length === 0) return '';

    // Filtrar apenas conceitos de alta importância para o fluxograma
    const highImportanceConcepts = concepts.filter(c => c.importance === 'high').slice(0, 8);
    
    if (highImportanceConcepts.length === 0) return '';

    let mermaid = '```mermaid\n';
    mermaid += 'flowchart TD\n';
    mermaid += '    classDef important fill:#ffc107,stroke:#333;\n';
    mermaid += '    classDef theory fill:#28a745,color:white;\n';
    mermaid += '    classDef person fill:#dc3545,color:white;\n\n';

    // Nó principal
    mermaid += `    A[${this.sanitizeForMermaid(title)}] --> B{Conceitos Principais}\n`;

    // Conectar conceitos principais
    highImportanceConcepts.forEach((concept, index) => {
      const nodeId = String.fromCharCode(67 + index); // C, D, E, F...
      const cleanName = this.sanitizeForMermaid(concept.name);
      mermaid += `    B --> ${nodeId}[${cleanName}]\n`;
      
      // Aplicar classe baseada na categoria
      if (concept.category === 'theory') {
        mermaid += `    ${nodeId}:::theory\n`;
      } else if (concept.category === 'person') {
        mermaid += `    ${nodeId}:::person\n`;
      } else {
        mermaid += `    ${nodeId}:::important\n`;
      }
    });

    mermaid += '```\n';
    return mermaid;
  }

  generateTimelineFromContent(content: ProcessedContent): string {
    // Analisar o texto para identificar datas e eventos
    const timelineEvents = this.extractTimelineEvents(content.originalText);
    
    if (timelineEvents.length === 0) return '';

    let mermaid = '```mermaid\n';
    mermaid += 'timeline\n';
    mermaid += `    title Linha do Tempo - ${content.metadata.title || 'Documento'}\n`;

    // Agrupar eventos por período
    const groupedEvents = this.groupEventsByPeriod(timelineEvents);

    Object.entries(groupedEvents).forEach(([period, events]) => {
      mermaid += `    section "${period}"\n`;
      events.forEach(event => {
        mermaid += `        ${event.year} : ${this.sanitizeForMermaid(event.description)}\n`;
      });
    });

    mermaid += '```\n';
    return mermaid;
  }

  generateProcessDiagram(content: ProcessedContent): string {
    // Identificar processos ou etapas no texto
    const processes = this.extractProcessSteps(content.originalText);
    
    if (processes.length < 2) return '';

    let mermaid = '```mermaid\n';
    mermaid += 'flowchart LR\n';
    mermaid += '    classDef process fill:#e3f2fd,stroke:#1976d2;\n\n';

    processes.forEach((process, index) => {
      const currentNode = `P${index + 1}`;
      const nextNode = `P${index + 2}`;
      
      mermaid += `    ${currentNode}[${this.sanitizeForMermaid(process)}]:::process\n`;
      
      if (index < processes.length - 1) {
        mermaid += `    ${currentNode} --> ${nextNode}\n`;
      }
    });

    mermaid += '```\n';
    return mermaid;
  }

  generateComparisonChart(concepts: ConceptData[]): string {
    // Criar um gráfico de quadrantes baseado na importância e categoria
    const theoryConcepts = concepts.filter(c => c.category === 'theory');
    const practicalConcepts = concepts.filter(c => c.category === 'term' || c.category === 'formula');
    
    if (theoryConcepts.length === 0 && practicalConcepts.length === 0) return '';

    let mermaid = '```mermaid\n';
    mermaid += 'quadrantChart\n';
    mermaid += '    title Análise de Conceitos\n';
    mermaid += '    x-axis Baixa Complexidade --> Alta Complexidade\n';
    mermaid += '    y-axis Teórico --> Prático\n';
    mermaid += '    quadrant-1 Teorias Complexas\n';
    mermaid += '    quadrant-2 Teorias Básicas\n';
    mermaid += '    quadrant-3 Conceitos Básicos\n';
    mermaid += '    quadrant-4 Aplicações Práticas\n';

    // Posicionar conceitos nos quadrantes (simplificado)
    concepts.slice(0, 10).forEach(concept => {
      const x = concept.category === 'formula' || concept.category === 'theory' ? 0.7 : 0.3;
      const y = concept.category === 'theory' ? 0.7 : 0.3;
      mermaid += `    ${this.sanitizeForMermaid(concept.name)}: [${x}, ${y}]\n`;
    });

    mermaid += '```\n';
    return mermaid;
  }

  private sanitizeForMermaid(text: string): string {
    return text
      .replace(/[()]/g, '') // Remover parênteses
      .replace(/[[\]]/g, '') // Remover colchetes
      .replace(/[{}]/g, '') // Remover chaves
      .replace(/"/g, "'") // Substituir aspas duplas por simples
      .replace(/\n/g, ' ') // Substituir quebras de linha por espaços
      .trim()
      .substring(0, 50); // Limitar tamanho
  }

  private groupConceptsByCategory(concepts: ConceptData[]): Record<string, ConceptData[]> {
    return concepts.reduce((groups, concept) => {
      const category = concept.category;
      if (!groups[category]) {
        groups[category] = [];
      }
      groups[category].push(concept);
      return groups;
    }, {} as Record<string, ConceptData[]>);
  }

  private getCategoryDisplayName(category: string): string {
    const categoryMap: Record<string, string> = {
      'person': 'Pessoas',
      'place': 'Lugares',
      'theory': 'Teorias',
      'formula': 'Fórmulas',
      'term': 'Termos',
      'other': 'Outros'
    };
    return categoryMap[category] || category;
  }

  private extractTimelineEvents(text: string): Array<{ year: string; description: string }> {
    const events: Array<{ year: string; description: string }> = [];
    
    // Regex para encontrar anos (1900-2099) seguidos de contexto
    const yearRegex = /\b(19|20)\d{2}\b/g;
    const sentences = text.split(/[.!?]+/);
    
    sentences.forEach(sentence => {
      const yearMatch = sentence.match(yearRegex);
      if (yearMatch) {
        yearMatch.forEach(year => {
          const description = sentence.trim().substring(0, 100);
          if (description.length > 10) {
            events.push({ year, description });
          }
        });
      }
    });

    // Remover duplicatas e limitar
    const uniqueEvents = events.filter((event, index, self) => 
      index === self.findIndex(e => e.year === event.year)
    ).slice(0, 10);

    return uniqueEvents.sort((a, b) => parseInt(a.year) - parseInt(b.year));
  }

  private groupEventsByPeriod(events: Array<{ year: string; description: string }>): Record<string, Array<{ year: string; description: string }>> {
    const grouped: Record<string, Array<{ year: string; description: string }>> = {};
    
    events.forEach(event => {
      const year = parseInt(event.year);
      let period: string;
      
      if (year < 1950) {
        period = 'Período Inicial';
      } else if (year < 1980) {
        period = 'Desenvolvimento';
      } else if (year < 2000) {
        period = 'Modernização';
      } else {
        period = 'Era Contemporânea';
      }
      
      if (!grouped[period]) {
        grouped[period] = [];
      }
      grouped[period].push(event);
    });
    
    return grouped;
  }

  private extractProcessSteps(text: string): string[] {
    const steps: string[] = [];
    
    // Procurar por indicadores de processo
    const processIndicators = [
      /primeiro[a]?\s*[,:]\s*([^.!?]+)/gi,
      /segundo[a]?\s*[,:]\s*([^.!?]+)/gi,
      /terceiro[a]?\s*[,:]\s*([^.!?]+)/gi,
      /em seguida[,:]\s*([^.!?]+)/gi,
      /depois[,:]\s*([^.!?]+)/gi,
      /finalmente[,:]\s*([^.!?]+)/gi,
      /por fim[,:]\s*([^.!?]+)/gi,
      /etapa\s*\d+[,:]\s*([^.!?]+)/gi,
      /passo\s*\d+[,:]\s*([^.!?]+)/gi
    ];

    processIndicators.forEach(regex => {
      let match;
      while ((match = regex.exec(text)) !== null) {
        const step = match[1].trim();
        if (step.length > 10 && step.length < 100) {
          steps.push(step);
        }
      }
    });

    // Remover duplicatas e limitar
    return [...new Set(steps)].slice(0, 8);
  }

  // Método para determinar qual tipo de diagrama é mais apropriado
  suggestBestDiagram(content: ProcessedContent): string {
    const text = content.originalText.toLowerCase();
    const concepts = content.concepts;

    // Verificar se há indicadores de timeline
    if (this.extractTimelineEvents(content.originalText).length >= 3) {
      return 'timeline';
    }

    // Verificar se há indicadores de processo
    if (this.extractProcessSteps(content.originalText).length >= 3) {
      return 'process';
    }

    // Se há muitos conceitos teóricos, usar flowchart
    const theoryCount = concepts.filter(c => c.category === 'theory').length;
    if (theoryCount >= 3) {
      return 'flowchart';
    }

    // Se há conceitos variados, usar mindmap
    if (concepts.length >= 5) {
      return 'mindmap';
    }

    // Padrão
    return 'mindmap';
  }
}

